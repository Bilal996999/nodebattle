module.exports = {
  gridRows: 10,
  gridCols: 10,
  ships: [ 5, 4, 3, 3, 2 ]
};
