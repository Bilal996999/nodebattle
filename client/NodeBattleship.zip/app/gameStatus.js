module.exports = {
  inProgress: 1,
  gameOver: 2
};

